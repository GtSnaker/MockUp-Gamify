# bower-phaser

The source for this package is in the [main Phaser repo](https://github.com/photonstorm/phaser).

## Install

Install with `bower`:

```shell
bower install phaser
```

Add a `<script>` to your HTML:

```html
<script src="/bower_components/phaser/phaser.js"></script>
```
